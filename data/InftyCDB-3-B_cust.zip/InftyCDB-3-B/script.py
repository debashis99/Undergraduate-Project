#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 21 20:49:20 2018

@author: jenil
"""

import pandas as pd
import numpy as np
import os
import cv2

o2c = np.array(pd.read_csv('OcrCodeList.txt', header=None))
info = np.array(pd.read_csv('CharInfoDB-3-B_Info.txt'))

dict = {'name' : 12}

for i in range(o2c.shape[0]):
    dict[o2c[i][0]] = o2c[i][2]

for j in range(info.shape[0]):
    try:
        dict['0x'+info[j][1]]
        try:
            os.mkdir('data/' + dict['0x'+info[j][1]])
        except:
            d=1
        img = cv2.imread('images/' + str(info[j][2]) + '.png')
        x = info[j][3]
        y = info[j][4]
        w = info[j][5]
        h = info[j][6]
        cutted_img = img[y:y+h, x:x+w]
        #cv2.imshow('img', cutted_img);
        print(j)
        cv2.imwrite('data/' + dict['0x'+info[j][1]] + '/' + str(j) + '.png', cutted_img)
        #cv2.waitKey(0)
        cv2.destroyAllWindows()
    except:
        continue
